import DataModel from "./DataModel";

interface Categoria extends DataModel<Categoria>{
    denominacion: string,
    
}

export default Categoria;