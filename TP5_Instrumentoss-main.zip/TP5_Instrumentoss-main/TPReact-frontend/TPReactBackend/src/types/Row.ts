
export default interface Row {
    [key: string]: any;
  }