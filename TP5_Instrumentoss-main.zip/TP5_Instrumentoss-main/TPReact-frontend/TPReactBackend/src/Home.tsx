import { useState } from "react";
import "./Home.css";

const Home = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const images = [
    "img/imagen1.jpg",
    "img/imagen2.jpg",
    "img/imagen3.jpg",
  ];
  const nextSlide = () => {
    setCurrentSlide(currentSlide === images.length - 1 ? 0 : currentSlide + 1);
  };

  const prevSlide = () => {
    setCurrentSlide(currentSlide === 0 ? images.length - 1 : currentSlide - 1);
  };

  return (
    <>
      <div className="slider-container">
        <h2 className="text-center fw-bold">TOCA Y BAILA</h2>
        <div className="slider">
          {images.map((image, index) => (
            <div
              key={index}
              className="slide"
              style={{
                transform: `translateX(-${currentSlide * 100}%)`,
                left: `${index * 100}%`,
                opacity: index === currentSlide ? 1 : 0,
              }}
            >
              <img src={image} alt={`Instrumento ${index + 1}`} />
            </div>
          ))}
        </div>
        <button className="prev" onClick={prevSlide}>
          {""}
        </button>
        <button className="next" onClick={nextSlide}>
          {""}
        </button>
      </div>
      <div className="descripcion-container">
        <p className="descripcion m-4">
        En "Toca y Baila" te ofrecemos una experiencia musical excepcional. 
        Explora nuestra cuidadosa selección de instrumentos de alta calidad que elevarán tu creatividad y pasión por la música. Desde guitarras cautivadoras hasta pianos resonantes, cada pieza está diseñada para inspirar. Descubre el sonido perfecto para tus melodías en "Toca y Baila".
        </p>
      </div>
    </>
  );
};

export default Home;
