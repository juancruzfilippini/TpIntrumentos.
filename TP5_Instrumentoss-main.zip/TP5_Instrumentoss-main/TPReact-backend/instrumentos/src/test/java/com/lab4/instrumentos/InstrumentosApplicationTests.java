package com.lab4.instrumentos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InstrumentosApplicationTests {

	@Test
	void contextLoads() {
	}

}
